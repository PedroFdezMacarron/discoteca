// {
//     "email" : "alba@mozas.com",
//     "password": "$2b$10$nK7d3HYFchoc870jZ6DFKuVAsHHHfnMkgJ.wwJzPJgCepnSezhem6",
//     "role": "admin"
// },
// {
//      "email" : "pedro@ugprade.com",
//      "password": "$2b$10$unUAg3W3JqL1mqk9XKGEVOcFVmwBGmDeEeA1xhZhPbos2D6/ATjZa",
//     "role": "admin"
// },
// {
//     "email": "pablo@mauricio.com",
//      "password": "$2b$10$OEJOBUPXjrl/xOBE8ehaNe53yTAceoadEiXmAyyZy3Q/Go64HUIvG",
//     "role": "admin"
// },
// {
//      "email" : "jose@playa.com",
//      "password": "$2b$10$1pSde/DGpXeQmhu7wDdx8eu2tzVo6QdIbQplGTAWJcCzgf37Hhplm",
//     "role": "admin"
// }

// {
// 	"email": "p@p.com",
// 	"password": "$2b$10$qwmdHc0Cvv1/AWvusfFYjeASeTmA0NkXm1vwYZMZUv8YR7MmCj1xi",
// 	"_id": "63c2710e918f148e56df3958",
// 	"__v": 0
// }"Pedro*1"

// {
// 	"email": "pp@p.com",
// 	"password": "$2b$10$jm4xNmvRdpIRTZ1Ac.POI.BWNqTqtxULX4AaTCGdmxeHLtpPZHuWS",
// 	"_id": "63c275737fa75c2a32427fc7",
// 	"__v": 0
// }
"email": "pp@p.com",
"password": "$2b$10$z8Pf2EZn52452NGWFktteO/xTclqVrvo2y8DPRl46DlJByupUssVG",
"role": "admin",
"_id": "63c27b81ee5834d0b7146421",
"__v": 0